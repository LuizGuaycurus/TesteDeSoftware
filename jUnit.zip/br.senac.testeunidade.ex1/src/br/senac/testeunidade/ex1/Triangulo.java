package br.senac.testeunidade.ex1;

public class Triangulo {

	private int a, b, c;
	private TipoTriangulo tipo;
	
	public Triangulo(int a, int b, int c) {
		this.a = a;
		this.b = b;
		this.c = c;
	}

	// TODO: implementar aqui o c�digo necess�rio para retornar o tipo correto de tri�ngulo
	public TipoTriangulo retornarTipo() {
		Triangulo t = new Triangulo(10, 15, 20);
		if(a==0 && b==0 && c==0)
			return tipo.INVALIDO;
		else if(a==b && b==c && c==a) 
			return tipo.EQUILATERO;
		else if(a!=b && b!=c && c!=a) 
			return tipo.ESCALENO;
		else if(a==b && b!=c&&a!=c || a==c && a!=b && c!=b || b==c && b!=a && c!=a) 
			return tipo.ISOCELES;
		
		return null;
	}
}
