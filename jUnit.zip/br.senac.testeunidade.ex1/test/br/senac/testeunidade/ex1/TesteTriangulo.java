package br.senac.testeunidade.ex1;

import static org.junit.Assert.*;
import org.junit.Test;

public class TesteTriangulo {

	@Test 
	public void testarTrianguloEquilatero() {
		
		Triangulo equilatero = new Triangulo(3, 3, 3);
		assertEquals(equilatero.retornarTipo(), TipoTriangulo.EQUILATERO);
		
	}
	
	@Test public void testarEscalenoValido() {
		Triangulo escaleno = new Triangulo(3, 4, 5);
		assertEquals(TipoTriangulo.ESCALENO, escaleno.retornarTipo());
	}
	
	@Test public void testarLadoNegativo() {
		Triangulo neg = new Triangulo(0,0,0);
		assertEquals(TipoTriangulo.INVALIDO, neg.retornarTipo());
	}


	
	@Test(expected=RuntimeException.class)
	public void testarExcecao() {
		Triangulo inv = new Triangulo(
				Integer.valueOf("999999999999999999"), 1, 3);
	}
}

