package br.senac.testeunidade.ex2;

public class Pilha {

	int tamanhoMaximo;
	
	public void inicializar(int tamanhoMaximo) {
		this.tamanhoMaximo = tamanhoMaximo;
	}
	
	public boolean empilhar(int numero){
		return false;
	}
	
	public int desempilhar() throws IndexOutOfBoundsException {
		return 0;
	}
	
	public boolean cheia() {
		return false;
	}
	
	public boolean vazia() {
		return false;
	}
	
}
