package br.senac.testeunidade.ex2;

import static org.junit.Assert.*;
import org.junit.Test;

public class TestePilha {
	@Test
	public void TestarPilha() {
		
		Pilha pilha = new Pilha();
		pilha.inicializar(5);
		pilha.empilhar(1);
		pilha.empilhar(2);
		pilha.empilhar(3);
		pilha.empilhar(4);
		pilha.empilhar(5);
		pilha.cheia();
		pilha.desempilhar();
		pilha.desempilhar();
		pilha.desempilhar();
		pilha.desempilhar();
		pilha.desempilhar();
		pilha.vazia();
		assertEquals(pilha.cheia(),false);
		assertEquals(pilha.vazia(),false);
		assertEquals(pilha.empilhar(5),false);
		assertEquals(pilha.desempilhar(),0);
	}
}
